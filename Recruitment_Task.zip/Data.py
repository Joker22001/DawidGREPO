import pandas as pd
import os, glob

FOLDER_WEJSCIOWY = 'DATA'
FOLDER_WYJSCIOWY = 'CONVERTED'

if not os.path.exists(FOLDER_WYJSCIOWY):
    os.makedirs(FOLDER_WYJSCIOWY)

sciezki = glob.glob(os.path.join(FOLDER_WEJSCIOWY, "*.csv"))

dfs = {}
def popraw_opisy_pkd(tekst):
    t = str(tekst)

    if 'dział 26' in t or 'dzial 26' in t:
        return "produkcja komputerów, wyrobów elektronicznych i optycznych"
    if 'dział 27' in t or 'dzial 27' in t:
        return "produkcja urządzeń elektrycznych"
    return t

for sciezka in sciezki:
    nazwa_pliku = os.path.basename(sciezka)

    czesci = nazwa_pliku.split('_')
    prefix = "_".join(czesci[:2])
    nowa_nazwa_pliku = f"{prefix}.csv"

    df = pd.read_csv(sciezka, sep=';', encoding='utf-8')
    
    df.columns = [c.strip() for c in df.columns]

    # --- FILTRACJA I USUNIĘCIE KOLUMNY OKRESY ---
    if 'Okresy' in df.columns:

        df = df[df['Okresy'].astype(str).str.contains('rok', case=False, na=False)]

        df = df.drop(columns=['Okresy'])
    # ---------------------------------------------

    # 1. POBIERANIE JEDNOSTKI (zanim usuniemy kolumny)
    jednostka_naglowek = ""
    if 'Jednostka miary' in df.columns:
        surowa_jednostka = str(df['Jednostka miary'].iloc[0]).strip()
        
        if surowa_jednostka != "-" and surowa_jednostka != "nan" and surowa_jednostka != "":
            jednostka_naglowek = f" [{surowa_jednostka}]"

    # 2. CZYSZCZENIE KOLUMN (poprzednie kroki)
    KOLUMNY_DO_USUNIECIA = ['Rodzaje działalności', 'Sektory własności','Wskaźniki']
    df = df.drop(columns=KOLUMNY_DO_USUNIECIA, errors='ignore')

    # 3. ZMIANA NAZWY KOLUMNY NA DYNAMICZNĄ
    nowa_nazwa_wartosci = f"Wartosc{jednostka_naglowek}"
    df = df.rename(columns={'Wartosc': nowa_nazwa_wartosci})

    # 4. FORMAT LICZBOWY (na nowej nazwie kolumny)
    df[nowa_nazwa_wartosci] = df[nowa_nazwa_wartosci].astype(str).str.replace(',', '.')
    df[nowa_nazwa_wartosci] = pd.to_numeric(df[nowa_nazwa_wartosci], errors='coerce')
    df = df.dropna(subset=[nowa_nazwa_wartosci])
    
    # 5. FINALNE CIĘCIE KOLUMN
    df = df.iloc[:, 1:-3]
    target_col = "Sekcje i działy według PKD 2007"
    if target_col in df.columns:
        df[target_col] = df[target_col].apply(popraw_opisy_pkd)
    # 6. ZAPIS
    dfs[nowa_nazwa_pliku] = df


if dfs:

    wspolne_lata = set.intersection(*(set(d['Rok']) for d in dfs.values()))
    
    if not wspolne_lata:
        print("Brak wspólnych lat!")
    else:
        min_r = min(wspolne_lata)
        max_r = max(wspolne_lata)
        print(f"zakres lat: {min_r} - {max_r}")


        for nazwa, df_final in dfs.items():

            df_zsynchronizowany = df_final[df_final['Rok'].isin(wspolne_lata)]
            
            sciezka_zapis = os.path.join(FOLDER_WYJSCIOWY, nazwa)
            df_zsynchronizowany.to_csv(sciezka_zapis, sep=';', index=False, encoding='utf-8-sig', decimal=',')
